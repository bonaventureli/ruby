
class Customer
    def hello
        puts "Hello, World."
    end
end

cust1 = Customer.new
cust2 = Customer. new # new 前面也可以有一个空格
cust1.hello
cust2.hello
